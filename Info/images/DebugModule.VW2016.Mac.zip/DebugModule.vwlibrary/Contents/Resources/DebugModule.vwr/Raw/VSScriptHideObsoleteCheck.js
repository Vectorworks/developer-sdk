function InitHideObsoleteCheck()
{
	var divObj = document.getElementById("hideObsoleteDiv");
	var savedTop = divObj.offsetTop;
	window.onscroll = function() {
		var doc = document.documentElement, body = document.body;
		var top = (doc && doc.scrollTop  || body && body.scrollTop  || 0);
        divObj.style.position = (top > savedTop) ? "fixed" : "relative";
    };
	
	var hideObsoleteCookie = 'false';
	if(window.localStorage)	hideObsoleteCookie = localStorage["hideObsoleteCheck"];
	else					hideObsoleteCookie = getCookie( 'hideObsoleteCheck', 'false' );
	
	var isChecked = (hideObsoleteCookie === 'true');
	document.getElementById("hideObsoleteCheck").checked = isChecked;
	updateElements( isChecked );
}

function OnHideObsoleteCheck(cb)
{
	setCookie( 'hideObsoleteCheck', cb.checked ? 'true' : 'false' );
	if(window.localStorage)
		localStorage["hideObsoleteCheck"] = cb.checked ? 'true' : 'false';
		
	var topElement = findFirstScrolledElement();
	
	updateElements( cb.checked );
	
	if ( topElement != null )
	{
		//topElement.scrollIntoView();
		window.scrollTo(0, topElement.offsetTop-10);
	}
}

function updateElements(isHidden)
{
	var allT = document.getElementsByTagName('*');
	
	var i=0, a;
    while( a=allT[i++] )
	{
		if ( a.className == 'obsolete' )
		{
			a.style.display = isHidden ? "none" : "block";
		}
    }
}

function findFirstScrolledElement()
{
	var result = null;
	
	var doc = document.documentElement, body = document.body;
	var cutoff = (doc && doc.scrollTop  || body && body.scrollTop  || 0);

	
	var all = document.getElementsByTagName("*");
	for (var i=0, max=all.length; i < max; i++)
	{
		var item = all[i];
		if ( item.offsetTop > cutoff )
		{
			result	= item;
			break;
		}
	}
	
	return result;
}

function setCookie(cname, cvalue)
{
	document.cookie = cname + "=" + cvalue + ";";
}

function getCookie(cname, defValue)
{
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for(var i=0; i<ca.length; i++) 
	{
		var c = ca[i].trim();
		if (c.indexOf(name)==0) return c.substring(name.length,c.length);
	}
	return defValue;
}