// StdAfx.cpp : source file that includes just the standard includes
// StdAfx.pch will be the pre-compiled header
// StdAfx.obj will contain the pre-compiled type information
//
//	Copyright � Nemetschek North America, Inc  2005.
//	All Rights Reserved.

#include "StdAfx.h"

