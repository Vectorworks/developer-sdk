//
// ExtMenu.cpp contains the code that runs when the VGSSample menu item is clicked.
// VGSSample uses VGSJournal header-library to log all VGS events, parameters, and 
// images to disk.  VGSSample can replay a saved log via gReplayLog variable.  
//
// USAGE:
//	MENU ITEM - If the VGSSample menu item is clicked it will print events as they happen to the output window
//		until the menu item is clicked a second time.
//	CTRL - If the menu item is clicked while CTRL is held down then events/parameters/textures/tessellation
//		will be logged (overriding what is there) to the working directory as they happen until the menu item 
//		is clicked a second time.  event names will be printed to the output window as they happen.
//	SHIFT - If the menu item is clicked while SHIFT is held down then events in the log will be replayed
//		as they did when the log was created.  See the outout window for the replay.
//
// This will be helpful:
// http://developer.vectorworks.net/index.php/SDK:Using_Shader_Records
//
#include "StdAfx.h"
#include "ExtMenu.h"
#include <sstream>
#include <string>

// Print to output window in release build
#ifdef _WIN32
#ifndef _DEBUG
#define DMSG2(programmer, message) ::OutputDebugStringA(message);
#undef DMSG
#define DMSG(params) DMSG2 params
#endif
#endif

using namespace VGSSample;
using namespace VectorWorks::Extension::VGS;

namespace VGSSample
{
	// --------------------------------------------------------------------------------------------------------
	static SMenuDef		gMenuDef = {
		/*Needs*/			0x00,
		/*NeedsNot*/		0x00,
		/*Title*/			{"CExtMenu", "title"},
		/*Category*/		{"CExtMenu", "category"},
		/*HelpText*/		{"CExtMenu", "help"},
		/*VersionCreated*/	25,
		/*VersoinModified*/	0,
		/*VersoinRetired*/	0
	};

	
		/*static SSTRResource	gMenuChunksDef[] = {
		{ {12000, 4}, "" },
		{ {12000, 5}, "" },
		{ {12000, 6}, "" },
		{ {12000, 7}, "" },
		{ {12000, 8}, "" },
		{ {NULL, NULL}, NULL }
	};*/

}

// --------------------------------------------------------------------------------------------------------
// {ACC6EE12-7A4B-45AF-AD23-2E462710E87A}
IMPLEMENT_VWMenuExtension(
	/*Extension class*/	CExtMenu,
	/*Event sink*/		CMenu_EventSink,
	/*Universal name*/	"RenderingPluginSample",
	/*Version*/			1,
	/*UUID*/			0xf1b04a4d, 0xfee6, 0x40ca, 0xb8, 0x76, 0x1c, 0xe5, 0x2c, 0x5d, 0x85, 0xc7);


// --------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------
CExtMenu::CExtMenu(CallBackPtr cbp)
	: VWExtensionMenu( cbp, gMenuDef, NULL )
{
}

CExtMenu::~CExtMenu()
{
}

// --------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------
CMenu_EventSink::CMenu_EventSink(IVWUnknown* parent)
	: VWMenu_EventSink( parent )
{
}

CMenu_EventSink::~CMenu_EventSink()
{
}

struct ProgressInfo {
	double numerator = 0.0;
	double denominator = 0.0;
};


static bool gbTreatAsExport = false; // treat the VGS plugin as a VGS geometry/scene export plugin
static bool gbDoProgress = gbTreatAsExport; // toggle this to turn on/off progress UI 

void CMenu_EventSink::ShowProgress(VCOMPtr<IVGS> renderPluginWrapper)
{
	if (gbDoProgress)
	{
		{
			std::unique_lock<std::mutex> lock(fProgressLock);

			VCOMPtr<VectorWorks::UI::IProgressDialog> progressUI(VectorWorks::UI::IID_ProgressDialog);
			progressUI->Open("Render Plugin Progress");
			progressUI->AllowUserCancel(false);
			progressUI->ResetMeter(100);
			double lastProgress = 0.0;
			if (fProgressInfo.numerator > 0.0)
				fProgressInfo.numerator = 0.0;
			// We need to wait for all of the events to come through before continuing
			fProgressCV.wait(lock, [&]() {
				double currProgress = (fProgressInfo.numerator / fProgressInfo.denominator)*100.0;
				double increment = currProgress - lastProgress;
				if (increment > 1)
				{
#if GS_MAC
                    progressUI->DoYield(); // The Mac doesn't show the values that were just set unless do this workaround.
#endif
					progressUI->IncrementMeter(static_cast<Uint16>(increment));
					lastProgress = currProgress;
				}
				return currProgress >= 100.0;
			});
			if (fProgressInfo.denominator < 20) // if we don't sleep in this case, the UI will close too quickly
				std::this_thread::sleep_for(std::chrono::seconds(2));
			progressUI->Close();
			fProgressInfo.numerator = 0.0;
			fProgressInfo.denominator = 0.0;
		}
		renderPluginWrapper->Unregister("myRenderPlugin");
	}
}

void CMenu_EventSink::DoInterface()
{
	// Register your interface or unregister here

	VCOMPtr<IVGS> renderPluginWrapper(IID_VGS);
	if( !renderPluginWrapper )
		return;

	if( renderPluginWrapper->IsRegistered("myRenderPlugin") )
		renderPluginWrapper->Unregister("myRenderPlugin");
	else
		renderPluginWrapper->RegisterN("myRenderPlugin", std::bind(&CMenu_EventSink::MyRenderPlugin, this, std::placeholders::_1), 0,
									  std::bind(&CMenu_EventSink::ProxyCallback, this, std::placeholders::_1),
									  std::bind(&CMenu_EventSink::MaterialDialogCallback, this, std::placeholders::_1),
									  gbTreatAsExport,/*make sure this parameter is true to output all parent chains in the scene*/
									  gbTreatAsExport/* This must be true if a one time sync is desired (i.e. for export plugins). We are assuming client will call Unregister after finishing.*/);
	ShowProgress(renderPluginWrapper);
}


// The goal of the render plugin callback is to translate and forward 
// events to your render engine
void CMenu_EventSink::MyRenderPlugin(::VGS::Operation& op)
{	
	switch( op.event )
	{
	case ::VGS::Event_ListenerSetup:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_ListenerSetup\n"));
		break;
	}
	case ::VGS::Event_ListenerSetdown:
	{
		DMSG((kJHutchison, "myRenderPlugin::Event_ListenerSetdown\n"));
		fProxyObjects.clear();
		fProxyToObjMap.clear();
		break;
	}
	case ::VGS::Event_ChangeBlockBegin:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_ChangeBlockBegin\n"));
		break;
	}
	case ::VGS::Event_ChangeBlockEnd:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_ChangeBlockEnd\n"));
		break;
	}
	case ::VGS::Event_TessellationAdd:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_TessellationAdd\n"));
		break;
	}
	case ::VGS::Event_TessellationRemove:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_TessellationRemove\n"));
		break;
	}
	case ::VGS::Event_TessellationModify:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_TessellationModify\n"));
		break;
	}
	case ::VGS::Event_ObjectAdd:
	{
		VGS_ID proxyID = op.objectAddArgs->proxyID;
		if (gbTreatAsExport && !(proxyID.lhs == 0 && proxyID.rhs == 0)) {
			if (fProxyToObjMap.find(proxyID) == fProxyToObjMap.end())
				fProxyToObjMap[proxyID] = op.objectAddArgs->objectID;
			else
				DMSG((kAGorbaty, "WARNING: OBJECT ID CLASH, THIS CAN BE BAD FOR SCENE GENERATION"));
		}
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_ObjectAdd\n"));
		break;
	}
	case ::VGS::Event_ObjectRemove:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_ObjectRemove\n"));
		break;
	}
	case ::VGS::Event_ObjectModifyTransform:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_ObjectModifyTransform\n"));
		break;
	}
	case ::VGS::Event_ObjectModifyMaterial:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_ObjectModifyMaterial\n"));
		break;
	}	
	case ::VGS::Event_ProxyObjectAdd:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_ProxyObjectAdd\n"));
		auto args = op.proxyObjectAddArgs;
		fProxyObjects[args->proxyID];
		break;
	}
	case ::VGS::Event_ProxyObjectModify:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_ProxyObjectModify\n"));
		auto args = op.proxyObjectModifyArgs;
		fProxyObjects[args->proxyID].fParameters = args->parameters;
		break;
	}
	case ::VGS::Event_ProxyObjectRemove:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_ProxyObjectRemove\n"));
		auto args = op.proxyObjectRemoveArgs;
		fProxyObjects.erase(args->proxyID);
		break;
	}
	case ::VGS::Event_MaterialAdd:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_MaterialAdd\n"));
		break;
	}
	case ::VGS::Event_MaterialRemove:
	{	
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_MaterialRemove\n"));
		break;
	}
	case ::VGS::Event_MaterialModify:
	{
		// Search fProxyObjects map with op.materialModifyArgs->materialID to see if proxy material currently exists.
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_MaterialModify\n"));
		break;
	}
	case ::VGS::Event_CameraModify:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_CameraModify\n"));
		break;
	}
	case ::VGS::Event_LightAdd:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_LightAdd\n"));
		break;
	}
	case ::VGS::Event_LightRemove:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_LightRemove\n"));
		break;
	}
	case ::VGS::Event_LightModify:
	{
		DMSG((kJHutchison, "myRenderPlugin VGS::Event_LightModify\n"));
		break;
	}
	case ::VGS::Event_ClipCubeAdd:
	{
		DMSG((kAGorbaty, "myRenderPlugin VGS::Event_ClipCubeAdd\n"));
		break;
	}
	case ::VGS::Event_ClipCubeModify:
	{
		DMSG((kAGorbaty, "myRenderPlugin VGS::Event_ClipPlanesModify\n"));
		break;
	}
	case ::VGS::Event_ClipCubeRemove:
	{
		DMSG((kAGorbaty, "myRenderPlugin VGS::Event_ClipCubeRemove\n"));
		break;
	}
	// more events....	
	}

	if (gbDoProgress && op.totalOperations > 0)
	{
		{
			std::unique_lock<std::mutex> lock(fProgressLock);
			fProgressInfo.numerator = static_cast<double>(op.completedOperations);
			fProgressInfo.denominator = static_cast<double>(op.totalOperations);
		}
		fProgressCV.notify_one();
	}
}

void CMenu_EventSink::ParseMaterial(VectorWorks::Extension::VGS::ProxyObjectArgs& args)
{
	VWTextureObj tex(args.fParentChain[0]); // material node

	bool tagBlob = true;
	if (!args.fBlob.second.empty())
	{
		// first entry in blob is whether it was generated by a user or was translated programatically.
		std::string key;
		int iVal;

		std::istringstream blob((const char*)args.fBlob.second.data());
		blob >> key;	// tempBlob
		blob >> iVal;	// value: 1 or 0
		tagBlob = iVal == 1;
	}

	if (tagBlob)
	{
		std::stringstream blob;
		blob << "tempBlob " << 1 << "\n";
		blob << "name " << tex.GetName().GetCharPtr() << "\n";
		blob << "size " << tex.GetSize() << "\n";

		VWTextureShaderColorBricks shader(tex);
		if (tex.GetShader(shader))
		{
			blob << "isColorBrick 1\n";
			blob << "brickWidth " << shader.GetBrickWidth() << "\n";
			blob << "brickHeight " << shader.GetBrickHeight() << "\n";
		}		

		args.fBlob.second.resize(blob.str().size());
		memcpy(&args.fBlob.second[0], blob.str().data(), args.fBlob.second.size());
	}
}

void CMenu_EventSink::ParseBackground(VectorWorks::Extension::VGS::ProxyObjectArgs& args)
{
	auto GetShaderRecordParameterLong = [&](MCObjectHandle inH, const short inFieldID, Sint32& outValue) {
		bool success = false;
		TRecordHandler rh(inH);
		TRecordItem recordItem(kFieldLongInt);

		if (VERIFYN(kAGorbaty, rh.GetFieldObject(inFieldID, recordItem)) && VERIFYN(kAGorbaty, recordItem.GetFieldValue(outValue)))
			success = true;
		return success;
	};

	auto GetShaderRecordRGB = [&](MCObjectHandle inH, const short inFieldID, Sint32& outR, Sint32& outG, Sint32& outB) {
		bool success = GetShaderRecordParameterLong(inH, inFieldID, outR);
		success &= GetShaderRecordParameterLong(inH, inFieldID + 1, outG);
		success &= GetShaderRecordParameterLong(inH, inFieldID + 2, outB);
		return success;
	};

	auto GetShaderRecordParameterDouble = [&](MCObjectHandle inH, const short inFieldID, double_gs& outValue) {
		bool success = false;
		TRecordHandler rh(inH);
		TRecordItem recordItem(kFieldReal);

		if (VERIFYN(kAGorbaty, rh.GetFieldObject(inFieldID, recordItem)) && VERIFYN(kAGorbaty, recordItem.GetFieldValue(outValue)))
			success = true;
		return success;
	};

	auto GetShaderRecordName = [&](MCObjectHandle inH, TXString& outValue) {
		TRecordHandler rh(inH);
		outValue = rh.GetLocalizedName();
	};

	enum BackgroundShaderPrototype {
		kCloudsBackground = 1,
		kOneColorBackground = 2,
		kTwoColorBackground = 3,
		kImageBackground = 4,
		kEnvironmentBackground = 5,
		kPhysicalSkyBackground = 6
	};

	const short kColor1 = 4;
	const short kColor2 = 7;
	const short kCloudsScale = 4;
	const short kBackgroundColor = 5;
	const short kCloudsColor = 8;
	const short kCloudsDetail = 11;

	auto &a = args.fParentChain[0];

	// Get the shader record of the background and begin to extract information about the backgrounds (mainly colors).
	// NOTE: The constants for the ShaderRecord parameters were found in Vectorworks internally. These can be subject to change.
	MCObjectHandle hBackgroundShaderRecord = gSDK->GetShaderRecord(a, kShaderFamily_Background);
	if (hBackgroundShaderRecord)
	{
		VWTextureShaderBase backgroundShader(hBackgroundShaderRecord);
		ShaderFamily backgroundFamily;
		Sint32 backgroundPrototype;
		if (backgroundShader.GetShaderRecordFamilyAndPrototype(backgroundFamily, backgroundPrototype))
		{
			switch (backgroundPrototype)
			{
			case BackgroundShaderPrototype::kOneColorBackground:
			{
				Sint32 colorR = 0, colorG = 0, colorB = 0;
				if (GetShaderRecordRGB(hBackgroundShaderRecord, kColor1, colorR, colorG, colorB))
				{
					std::stringstream blob;
					blob << "Background " << BackgroundShaderPrototype::kOneColorBackground << "\n";
					TXString name;
					GetShaderRecordName(hBackgroundShaderRecord, name);
					blob << "name " << name.GetStdString() << "\n";
					blob << "color " << colorR << "," << colorG << "," << colorB << "\n";
					args.fBlob.second.resize(blob.str().size());
					memcpy(&args.fBlob.second[0], blob.str().data(), args.fBlob.second.size());
				}
				break;
			}
			case BackgroundShaderPrototype::kTwoColorBackground:
			{
				Sint32 colorR1 = 0, colorG1 = 0, colorB1 = 0, colorR2 = 0, colorG2 = 0, colorB2 = 0;
				if (GetShaderRecordRGB(hBackgroundShaderRecord, kColor1, colorR1, colorG1, colorB1) &&
					GetShaderRecordRGB(hBackgroundShaderRecord, kColor2, colorR2, colorG2, colorB1))
				{
					std::stringstream blob;
					blob << "Background " << BackgroundShaderPrototype::kTwoColorBackground << "\n";
					TXString name;
					GetShaderRecordName(hBackgroundShaderRecord, name);
					blob << "name " << name.GetStdString() << "\n";
					blob << "color1 " << colorR1 << "," << colorG1 << "," << colorB1 << "\n";
					blob << "color2 " << colorR2 << "," << colorG2 << "," << colorB2 << "\n";
					args.fBlob.second.resize(blob.str().size());
					memcpy(&args.fBlob.second[0], blob.str().data(), args.fBlob.second.size());
				}
				break;
			}
			case BackgroundShaderPrototype::kCloudsBackground:
			{
				double_gs scale = 0.0;
				Sint32 backgroundColorR = 0, backgroundColorG = 0, backgroundColorB = 0, cloudsColorR = 0, cloudsColorG = 0, cloudsColorB = 0, detail = 0;
				if (GetShaderRecordParameterDouble(hBackgroundShaderRecord, kCloudsScale, scale) &&
					GetShaderRecordRGB(hBackgroundShaderRecord, kBackgroundColor, backgroundColorR, backgroundColorG, backgroundColorB) &&
					GetShaderRecordRGB(hBackgroundShaderRecord, kCloudsColor, cloudsColorR, cloudsColorG, cloudsColorB) &&
					GetShaderRecordParameterLong(hBackgroundShaderRecord, kCloudsDetail, detail))
				{
					std::stringstream blob;
					blob << "Background " << BackgroundShaderPrototype::kCloudsBackground << "\n";
					TXString name;
					GetShaderRecordName(hBackgroundShaderRecord, name);
					blob << "name " << name.GetStdString() << "\n";
					blob << "scale " << scale << "\n";
					blob << "backgroundColor " << backgroundColorR << "," << backgroundColorG << "," << backgroundColorB << "\n";
					blob << "cloudsColor " << cloudsColorR << "," << cloudsColorG << "," << cloudsColorB << "\n";
					blob << "cloudsDetail " << detail << "\n";
					args.fBlob.second.resize(blob.str().size());
					memcpy(&args.fBlob.second[0], blob.str().data(), args.fBlob.second.size());
				}
				break;
			}
			default: // I don't feel like implementing the others right now but this should give you an idea to add the remaining background shaders here
				break;
			}
		}
	}
}

void CMenu_EventSink::ProxyCallback0(VectorWorks::Extension::VGS::ProxyObjectArgs& args)
{
	enum ExitStatus { Success, BadInput };
	auto Exit = [&](ExitStatus status)
	{
		
	};

	if (args.fParentChain.empty()) Exit(BadInput);

	MCObjectHandle hRoot = args.fParentChain[0];
	short objType = gSDK->GetObjectTypeN(hRoot);
	if (setmember(objType, kTextureNode, kRenderBackgroundNode))
	{
		switch (objType)
		{
		case kTextureNode: ParseMaterial(args); args.fBlob.first = args.fParentChain[0];/*This is the actual proxy object*/ break;
		case kRenderBackgroundNode: ParseBackground(args); args.fBlob.first = args.fParentChain[0]; break;
		default:
			break;
		}
	}
	else
	{
		MCObjectHandle hFoundObj = nullptr;
		for (auto parentObj = args.fParentChain.rbegin(); parentObj != args.fParentChain.rend(); ++parentObj)
		{
			short type = gSDK->GetObjectType(*parentObj);
			if (setmember(type, kParametricNode, kLightNode))
			{
				hFoundObj = *parentObj;
				break;
			}
		}

		std::stringstream blob;
		if (hFoundObj)
		{
			VWFC::VWObjects::VWParametricObj p(hFoundObj);

			if (setmember(p.GetInternalID(), kInternalID_VbvisualPlantCW, kInternalID_RenderWorks_Camera))
			{
				args.fBlob.first = hFoundObj;
				blob << "name " << p.GetParametricName().GetCharPtr() << "\n";
				size_t numParams = p.GetParamsCount();
				for (size_t i = 0; i < numParams; i++)
				{
					TXString paramName = p.GetParamName(i);
					TXString value = p.GetParamAsString(paramName);
					blob << paramName.GetCharPtr() << " " << value.GetCharPtr() << "\n";
				}
			}
		}

		// Write out custom data based on the light kind (i.e. point, spotlight, directional, area, etc.)
		// For now, input a string telling us the light kind for the blob for each of the lights.
		if (gSDK->GetObjectTypeN(hFoundObj) == kLightNode)
		{
			args.fBlob.first = hFoundObj;
			Sint16 lightKind = kPointLight;
			TVariableBlock value;
			gSDK->GetObjectVariable(hFoundObj, ovLightKind, value);
			if (value.GetSint16(lightKind))
			{
				std::string lightKindName;
				switch (lightKind)
				{
				case kDirectionalLight: lightKindName = "directional"; break;
				case kPointLight: lightKindName = "point"; break;
				case kSpotLight: lightKindName = "spot"; break;
				default: lightKindName = "unknown";	break;
				}

				blob << "lightKind:" << lightKindName << std::endl;
			}
		}

		if (!blob.str().empty())
		{
			blob << '\0';
			args.fBlob.second.resize(blob.str().size());
			memcpy(&args.fBlob.second[0], blob.str().data(), args.fBlob.second.size());
		}
	}

	// If you want the Vectorworks scenegraph data, use this code to extract whatever you need.
	// NOTE: This code is necessary in the event where alwaysReturnParentChains==true in RegisterN
	if (gbTreatAsExport)
	{
		args.fBlob.first = args.fParentChain.back(); // set the child node as the reference node
		std::stringstream outBlob;
		for (auto& parent : args.fParentChain)
		{
			if (args.fBlob.first == parent)
				continue;
			// getting all parents for now; this can easily be changed
			outBlob << parent << " ";
		}

		outBlob << std::endl << '\0';
		args.fBlob.second.resize(outBlob.str().size());
		memcpy(&args.fBlob.second[0], outBlob.str().data(), args.fBlob.second.size());
		args.fRequestTessellation = true;
	}

	return Exit(Success);
}

void CMenu_EventSink::ProxyCallback1(VectorWorks::Extension::VGS::ProxyObjectArgs& args)
{
	args;
}

bool CMenu_EventSink::MaterialDialogCallback0(VectorWorks::Extension::VGS::ProxyMaterialArgs& args)
{
	bool okPressed = false;
#if GS_WIN
	// populate dialog controls with data in args.fBlob
	// show UI
	okPressed = MessageBoxA(0, "MaterialDialogcallback", "this is a test", MB_OKCANCEL) == IDOK;
#endif

	if( okPressed )
	{
		std::stringstream blob;

		blob << "tempBlob 0\n";
		blob << "name brick\n";
		blob << "brickWidth " << 256 << "\n";
		blob << "brickHeight " << 256 << "\n";

		// add to blob
		args.fBlob.clear();
		args.fBlob.insert(args.fBlob.end(), blob.str().begin(), blob.str().end());
	}

	return okPressed;
}


bool CMenu_EventSink::MaterialDialogCallback1(VectorWorks::Extension::VGS::ProxyMaterialArgs& args)
{
	args;
	return false;
}


void CMenu_EventSink::ProxyCallback(VectorWorks::Extension::VGS::ProxyObjectArgs& args)
{
	switch( fTest )
	{
	case 0: ProxyCallback0(args); break;
	case 1: ProxyCallback1(args); break;
	};
}

bool CMenu_EventSink::MaterialDialogCallback(VectorWorks::Extension::VGS::ProxyMaterialArgs& args)
{
	switch( fTest )
	{
	case 0: return MaterialDialogCallback0(args);
	case 1: return MaterialDialogCallback1(args);
	};
	return false;
}
