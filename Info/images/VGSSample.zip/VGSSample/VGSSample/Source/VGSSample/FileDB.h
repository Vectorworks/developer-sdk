// FileDB.h is a single header library implements a simple database query
// class.  The data is stored on disk and it's contents are re-parsed
// every 1 second.  The generic query functions can retrieve strings, ints,
// floats, doubles, and bools.  The file syntax is simply key=value, or key = value,
// or key="value with space" or "key with space" = "value with space"
//
// FileDB library only depends on standard c++ libraries
//

#ifndef FileDB_h
#define FileDB_h

#include <string>
#include <map>			// store data
#include <strstream>	// string manip
#include <fstream>
#include <chrono>		// for timing -- reload db every one second

class FileDB
{
public:
	FileDB(const std::string& filename) 
	{
		fFilename = filename;
	}

	bool GetString(const std::string& key, std::string& out)
	{
		Reload();
		auto it = fData.find(key);
		if( it == fData.end() )
			return false;

		out = it->second;
		return true;
	}

	bool GetInt(const std::string & key, int& out)
	{
		bool success = false;

		Reload();
		try
		{
			auto it = fData.find(key);
			if( it != fData.end() )
			{
				out = std::stoi(it->second);
				success = true;
			}
		}
		catch( ... )
		{
		}

		return success;
	}

	bool GetFloat(const std::string& key, float& out)
	{
		bool success = false;

		Reload();
		try
		{
			auto it = fData.find(key);
			if( it != fData.end() )
			{
				out = std::stof(it->second);
				success = true;
			}
		}
		catch( ... )
		{
		}

		return success;
	}

	bool GetDouble(const std::string& key, double& out)
	{
		bool success = false;

		Reload();
		try 
		{
			auto it = fData.find(key);
			if( it != fData.end() )
			{
				out = std::stod(it->second);
				success = true;
			}
		} 
		catch( ... )
		{
		}

		return success;
	}

	bool GetBool(const std::string& key, bool& out)
	{
		bool success = false;

		Reload();		
		try 
		{
			auto it = fData.find(key);
			if( it != fData.end() )
			{
				if( it->second=="true" || it->second == "1" )
				{
					out = true;
					success = true;
				}
				else if( it->second == "false" || it->second == "0" )
				{
					out = false;
					success = true;
				}
			}

		}
		catch( ... )
		{
		}

		return success;

	}
	
private:

	void Reload()
	{
		auto tick = std::chrono::high_resolution_clock::now();

		if( fFirst || std::chrono::duration_cast<std::chrono::milliseconds>(tick-fLastTick).count() > 1000 )  // reload every 1 second
		{
			fFirst = false;
			fLastTick = tick;

			std::ifstream file(fFilename);

			if( file.is_open() )
			{
				fData.clear();

				file.seekg(0, std::ios::end);
				size_t size = size_t(file.tellg());
				file.seekg(0, std::ios::beg);

				std::string contents;
				contents.resize(size+1);
				file.read(&contents[0], size);
				contents[size] = 0;

				file.close();

				size_t offset = 0;

#define CheckEOF(index) if( index >= contents.size() ) break

				while( offset < contents.size() )
				{
					std::string key;
					std::string value;


					offset = contents.find_first_not_of(" \t\n\r", offset);
					CheckEOF(offset);

					size_t endOffset = offset;

					if( contents[offset] == '"' )
						endOffset = contents.find_first_of("\"", ++offset);
					else
						endOffset = contents.find_first_of(" \t\n\r=", offset);

					if( offset == endOffset )
						endOffset++;
					CheckEOF(endOffset);

					key = contents.substr(offset, endOffset-offset);
					offset = endOffset;

					offset = contents.find_first_of("=", offset);
					offset++;
					CheckEOF(offset);

					offset = contents.find_first_not_of(" \t\n\r", offset);
					CheckEOF(offset);


					endOffset = offset;

					if( contents[endOffset] == '"' )
						endOffset = contents.find_first_of("\"", ++offset);					
					else
						endOffset = contents.find_first_of(" \t\n\r", endOffset);

					CheckEOF(endOffset);

					value = contents.substr(offset, endOffset-offset);
					fData[key] = value;

					offset = endOffset;

					offset = contents.find_first_of("\n\r", offset);
					offset++;
					CheckEOF(endOffset);
					
#undef CheckEOF
				}
			}
		}
	}

	bool fFirst = true;
	std::chrono::time_point<std::chrono::high_resolution_clock> fLastTick = std::chrono::high_resolution_clock::now();

	std::map<std::string, std::string> fData;  // key-value table of data read from disk
	std::string fFilename;
};

#endif
