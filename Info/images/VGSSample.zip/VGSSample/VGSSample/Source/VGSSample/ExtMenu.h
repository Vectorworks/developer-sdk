#pragma once
#include "VGS.h"
#include "Interfaces/VectorWorks/IVGS.h"

namespace VGSSample
{
	using namespace VWFC::PluginSupport;

	struct ProxyObject
	{
		std::vector<unsigned char> fParameters;
	};

	struct ProgressInfo {
		double numerator = 0.0;
		double denominator = 0.0;
	};

	// ------------------------------------------------------------------------------------------------------
	class CMenu_EventSink : public VWMenu_EventSink
	{
	public:
							CMenu_EventSink(IVWUnknown* parent);
		virtual				~CMenu_EventSink();

	public:
		virtual void		DoInterface();
		
	private:
		void MyRenderPlugin(::VGS::Operation& op);
		void ProxyCallback(VectorWorks::Extension::VGS::ProxyObjectArgs& args);
		bool MaterialDialogCallback(VectorWorks::Extension::VGS::ProxyMaterialArgs& args);

		void ParseMaterial(VectorWorks::Extension::VGS::ProxyObjectArgs& args);
		void ParseBackground(VectorWorks::Extension::VGS::ProxyObjectArgs& args);
		void ProxyCallback0(VectorWorks::Extension::VGS::ProxyObjectArgs& args);
		void ProxyCallback1(VectorWorks::Extension::VGS::ProxyObjectArgs& args);

		bool MaterialDialogCallback0(VectorWorks::Extension::VGS::ProxyMaterialArgs& args);
		bool MaterialDialogCallback1(VectorWorks::Extension::VGS::ProxyMaterialArgs& args);

		void ShowProgress(VCOMPtr<VectorWorks::Extension::VGS::IVGS> renderPluginWrapper);

		bool fLog = false;
		int fTest = 0;

		std::map<VGS_ID, ProxyObject> fProxyObjects;
		std::map <VGS_ID, VGS_ID> fProxyToObjMap;


		std::mutex fProgressLock;
		std::condition_variable fProgressCV;
		ProgressInfo fProgressInfo;
	};

	// ------------------------------------------------------------------------------------------------------
	class CExtMenu : public VWExtensionMenu
	{
		DEFINE_VWMenuExtension;
	public:
										CExtMenu(CallBackPtr cbp);
		virtual							~CExtMenu();

	};
}